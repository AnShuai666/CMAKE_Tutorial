/*
	hello 头文件 示范
*/

#include <iostream>

int hello();

