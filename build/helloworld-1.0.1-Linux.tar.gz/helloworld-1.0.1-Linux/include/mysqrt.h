//
// Created by yhl on 19-3-18.
//

#ifndef HELLOWORLD_MYSQRT1_H
#define HELLOWORLD_MYSQRT1_H

#include <math.h>

double mysqrt(double in);
double mysqrt_1(double x);

#endif //HELLOWORLD_MYSQRT1_H
